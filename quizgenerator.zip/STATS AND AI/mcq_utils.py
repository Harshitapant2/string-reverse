import fitz  # PyMuPDF
import random
import nltk
import re
from nltk.corpus import wordnet, stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from transformers import pipeline
from bs4 import BeautifulSoup

# NLTK data
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('stopwords')

stop_words = set(stopwords.words('english'))

# ----------- PDF Extraction -----------
def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text()
    doc.close()
    return text

# ----------- Text Preprocessing -----------
def clean_html(raw_html):
    return BeautifulSoup(raw_html, "html.parser").get_text()

def remove_references(text):
    return re.sub(r'\[\d+\]', '', text)

def remove_equations(text):
    return re.sub(r'\$.*?\$', '', text)

def normalize_text(text):
    text = text.lower()
    text = re.sub(r'\n+', ' ', text)
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    words = word_tokenize(text)
    filtered_words = [word for word in words if word not in stop_words and len(word) > 2]
    return ' '.join(filtered_words)

def preprocess_ncert_text(raw_text):
    text = clean_html(raw_text)
    text = remove_references(text)
    text = remove_equations(text)
    sentences = sent_tokenize(text)
    cleaned_sentences = [normalize_text(sent) for sent in sentences]
    cleaned_text = ' '.join(cleaned_sentences)
    return cleaned_text

# ----------- Distractor Generator -----------
def get_distractors(word):
    distractors = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            name = lemma.name().replace("_", " ")
            if name.lower() != word.lower() and name.isalpha():
                distractors.add(name)
    return list(distractors)[:3]

# ----------- Main Quiz Generator -----------
def generate_mcqs_from_pdf(pdf_path, topic, return_json=False):
    raw_text = extract_text_from_pdf(pdf_path)
    text = raw_text  # or: preprocess_ncert_text(raw_text)

    sentences = sent_tokenize(text)
    filtered_sentences = [s for s in sentences if topic.lower() in s.lower()]

    if not filtered_sentences:
        if return_json:
            return []
        print(f"❌ No content found for topic '{topic}'")
        return

    random.shuffle(filtered_sentences)
    fill_mask = pipeline("fill-mask", model="distilroberta-base")
    quiz = []

    for sent in filtered_sentences:
        words = sent.split()
        if len(words) < 8:
            continue

        idx = random.randint(0, len(words) - 1)
        answer = words[idx]
        if not answer.isalpha() or len(answer) < 4:
            continue

        words[idx] = fill_mask.tokenizer.mask_token
        masked_sentence = ' '.join(words)

        try:
            predictions = fill_mask(masked_sentence)
            distractors = get_distractors(answer)
            if not distractors:
                continue

            options = distractors + [answer]
            random.shuffle(options)

            question = {
                "question": masked_sentence.replace(fill_mask.tokenizer.mask_token, "_____"),
                "options": options,
                "answer": answer
            }
            quiz.append(question)
            if len(quiz) >= 5:
                break
        except Exception:
            continue

    # Return quiz JSON (for Flask) or print if not used by Flask
    if return_json:
        return quiz
    elif quiz:
        print("\n📘 Generated MCQs:\n")
        for i, item in enumerate(quiz, 1):
            print(f"Q{i}: {item['question']}")
            for j, opt in enumerate(item['options']):
                print(f"   {chr(65 + j)}. {opt}")
            print(f"   ✅ Answer: {item['answer']}\n")
    else:
        print(f"⚠ No MCQs could be generated for the topic '{topic}'.")

# ----------- CLI Use (Optional) -----------
if __name__ == "__main__":
    pdf_path = input("Enter the path to your NCERT PDF: ").strip()
    topic = input("Enter a topic : ").strip()
    generate_mcqs_from_pdf(pdf_path, topic)
