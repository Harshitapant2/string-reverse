from flask import Flask, request, render_template, redirect, url_for
import os
from mcq_utils import generate_mcqs_from_pdf
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        # Check if a file is uploaded
        if 'pdf' not in request.files:
            return "⚠️ No file part", 400

        file = request.files['pdf']
        topic = request.form.get('topic')

        if file.filename == '':
            return "⚠️ No selected file", 400

        if not topic:
            return "⚠️ Please provide a topic", 400

        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Generate MCQs
        mcqs = generate_mcqs_from_pdf(filepath, topic, return_json=True)

        return render_template('quiz.html', mcqs=mcqs, topic=topic)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
